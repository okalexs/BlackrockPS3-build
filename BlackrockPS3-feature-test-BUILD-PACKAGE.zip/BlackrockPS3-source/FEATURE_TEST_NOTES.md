# Blackrock PS3 — guarded feature test (2026-10-31)

This is **build-ready C++ source**, not a prebuilt Windows executable.
The existing PS3MAPI connection-stability patch is retained.

## Entity spawning
- Switched the Spawner UI from the persistent in-game command-handler path to the source's existing one-shot guarded `spawnAt()` path.
- Before native execution, require the EBOOT fingerprint, readable world structures, a resident entity definition, matching entity type, sObject pool, and creation-depth checks.
- For initial validation, one spawn request at a time (even if the UI asks for more). The previous handler could attempt eight spawns in one frame.
- Block unsupported/risky entity types and **block bipeds (including Patches 99-40)** because this console previously hard-froze on a biped. A correct squad-aware constructor is *not* established.
- Native `sobject_new` may still freeze on otherwise permitted entity types. Do not repeatedly test it on a production save.

## Pickup filters
- Each installation step now has a named error stage in the log and UI (preset compilation, EBOOT/item table verification, bitmap write, hook installation, hook/bitmap read-back).
- Verify the installed hook instruction, mode, and complete 820-byte bitmap after attempting activation.
- On failure, restore the previous preset when possible. Otherwise revert the hook and clear the active state.
- Correctly distinguishing activation from item-rejection behavior requires **live EBOOT argument verification**. The injected pickup stub's assumption that `r4` points to a 16-bit item index has not been confirmed. The filter may install but still reject the wrong items.

## Limitations
- These edits passed Linux C++ syntax-only checks with a Windows-function declaration shim. They have not been built with MSVC or executed against a physical PS3.
- The source files include existing code paths for unrelated features; no guarantee is made about those features.
- If a filter does not activate, capture the `Activation failed during ...` line from `%LOCALAPPDATA%\BlackrockPS3\blackrock.log` rather than repeatedly switching it on.
- Do not attempt Patches 99-40: the new path refuses bipeds deliberately.
- Use a private GitHub repo and `.github/workflows/build-windows.yml` for a Windows executable when there is no room on C: for Visual Studio.

## Test order
1. Test PS3MAPI connection alone; confirm it remains stable.
2. Test pickup preset activation, confirm the page reports `On` and logs `verified filter on`. This verifies installation, **not filtering correctness**.
3. Test item-rejection behavior with a disposable item in a controlled environment. If the hook installs but the wrong item is blocked, stop and supply logs; do not change undocumented register assumptions blindly.
4. Only after the above, consider a **single harmless loaded prop**, not a biped, if you accept the risk of a console freeze.
