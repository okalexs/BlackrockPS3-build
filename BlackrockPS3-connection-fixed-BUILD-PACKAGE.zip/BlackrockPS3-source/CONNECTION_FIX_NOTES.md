# Blackrock PS3 — PS3MAPI connection-stability patch

## Root problem

Previously, `Ps3Mapi::line()` flagged late replies as `desync_`, and the next `ready()` call unconditionally dropped the control socket and invoked `reopen()`. That function attempted to create a new TCP control session with only a short exponential backoff, while `Engine::refreshMain()` continued querying the console's heartbeat every 250 ms. Errors during PASV data transfers could likewise trigger repeated automatic reconnection attempts.

## Changes

- `src/core/ps3mapi.cpp` and `.h`: removed `reopen()`, the static backoff map, and `markHealthy()`; a broken or ambiguous session is now latched offline until the user explicitly creates a new session.
- Control receive errors, send failures, malformed replies, failed PASV data connections, incomplete memory reads, and unacknowledged writes close the affected control connection instead of reusing or reconnecting it.
- Completed memory-transfer replies are checked while the instance mutex is held to avoid racing other threads that share the control socket.
- `sendAll()` now handles the case where `send()` returns zero rather than looping forever.
- `src/app/engine.cpp`: slowed background heartbeat monitoring from 250 ms to 1000 ms, skips checks while a job or loop is running, detects a closed PS3MAPI session promptly, and disconnects without new cleanup I/O over a failed socket.
- `src/core/session.cpp`: leaves the recovery journal intact when destruction occurs after a connection failure; it doesn't attempt restoration through a failed link.

## Important behavior

A transient PS3MAPI timeout now ends the current application session rather than retrying automatically. This prioritizes avoiding repeated control connections that might overload the console. Use **Recover** when the tool reports a pending patch journal; then click **Connect** again. Normal PASV data sockets for individual memory operations are still used, since that is part of the PS3MAPI protocol.

## Validation scope

The actual `ps3mapi.cpp` built with clang++ using temporary POSIX-backed Winsock mock headers on Linux. A fake PS3MAPI server supplied the expected 220/230 handshake and a successful command, then deliberately withheld its next response. The test observed a timeout, 25 subsequent rejected operations and a **total of only one accepted control connection**.

The complete Windows GUI cannot be built in this environment because the Windows/Visual Studio C++ toolchain is not available, and there is no access to your console. Use `BUILD_WINDOWS.ps1` on Windows and verify the results in a test session.
