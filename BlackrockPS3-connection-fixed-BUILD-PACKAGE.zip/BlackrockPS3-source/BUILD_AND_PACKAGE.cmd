@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_AND_PACKAGE.ps1"
if errorlevel 1 (
  echo.
  echo Build failed. Read the error above. The EXE was NOT produced.
  pause
  exit /b 1
)
echo.
echo New EXE and ready-to-use release ZIP created in the out and dist folders.
pause
