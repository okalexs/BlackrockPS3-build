# Blackrock PS3 — minimal source package

Build with Visual Studio 2022 (Desktop C++) and CMake 3.20+:

    cmake -S . -B build -G "Visual Studio 17 2022" -A x64
    cmake --build build --config Release -- /m:8

The executable and runtime data are copied to `out/`. This package contains only the files needed to build and run the Windows app: `src/`, `data/`, CMake, and the required Dear ImGui files. The game dump, research, alternate source snapshot, old build directories, and development tools are omitted.

Target: Destiny NPEB02021, APP_VER 01.24, build 51539.16.07.26.1808.v230, on PS3 HEN with webMAN MOD PS3MAPI. The developer's offline tests do not establish that ported features work on a live console; use the app's TESTING > Port checks workflow.

## PS3MAPI connection-stability fix (2026-10-30)

Build the patched app in Windows PowerShell (requires Visual Studio 2022 **Desktop development with C++** and CMake):

    cd 'C:\path\to\BlackrockPS3-source'
    powershell -ExecutionPolicy Bypass -File .\BUILD_WINDOWS.ps1

Then run `out\blackrock-ps3.exe`. Do not replace just the EXE's data folder without checking the build has copied the matching `data/` directory.

The PS3MAPI **control connection** is now kept for the duration of a healthy session; PS3MAPI data transfer sockets still open as required by its PASV protocol. If an operation times out or the stream becomes ambiguous, Blackrock closes the socket and **stops sending traffic** instead of silently reconnecting. The background heartbeat checks once per second rather than four times per second, and skips an active job/loop. A failed transport triggers disconnection without trying additional cleanup commands over the bad link. When a pending patch journal exists, use the built-in **Recover** action after PS3MAPI becomes accessible again before connecting normally. Do not delete the journal as a substitute for recovery.

Testing: the patched PS3MAPI translation unit was compiled against a Linux Winsock compatibility shim and exercised against a mock TCP server. The test verified one successful control connection, an induced timeout, 25 subsequent fail-closed calls, and zero reconnection attempts. This is **not** a Windows application build or a live-console test; validate against a real PS3 before relying on it for patches.
