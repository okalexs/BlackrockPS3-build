# Run from PowerShell on Windows with Visual Studio 2022 C++ tools and CMake 3.20+.
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$build = Join-Path $root 'build'
if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
    throw 'CMake is not installed or not on PATH. Install Visual Studio 2022 with Desktop development with C++ and CMake tools.'
}
cmake -S $root -B $build -G 'Visual Studio 17 2022' -A x64
if ($LASTEXITCODE -ne 0) { throw 'CMake configuration failed. Verify the Desktop development with C++ workload is installed.' }
cmake --build $build --config Release --parallel 8
if ($LASTEXITCODE -ne 0) { throw 'CMake build failed. Read the compiler errors above.' }
Write-Host "Build complete: $root\out\blackrock-ps3.exe" -ForegroundColor Green
Write-Host 'The application data folder is copied beside the EXE.'
