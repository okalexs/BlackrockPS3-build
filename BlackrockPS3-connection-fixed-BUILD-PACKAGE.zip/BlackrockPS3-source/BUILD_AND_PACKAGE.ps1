# Build the patched Blackrock PS3 application and package a Windows x64 release.
# Requirements: Windows, Visual Studio 2022 / Build Tools with Desktop development
# with C++, CMake 3.20+, and enough available disk space.
$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$buildDir = Join-Path $root 'build'
$outDir = Join-Path $root 'out'
$distDir = Join-Path $root 'dist'
$releaseDir = Join-Path $distDir 'BlackrockPS3-connection-fixed-win64'
$archive = Join-Path $distDir 'BlackrockPS3-connection-fixed-win64.zip'

try {
    if (-not (Get-Command cmake -ErrorAction SilentlyContinue)) {
        throw 'CMake not found. Install Visual Studio 2022 Build Tools and select Desktop development with C++ (including CMake).'
    }
    Write-Host 'Configuring Blackrock PS3 (x64, Visual Studio 2022)...' -ForegroundColor Cyan
    & cmake -S $root -B $buildDir -G 'Visual Studio 17 2022' -A x64
    if ($LASTEXITCODE -ne 0) { throw "CMake configure failed (exit $LASTEXITCODE)." }

    Write-Host 'Compiling the patched Blackrock PS3 EXE...' -ForegroundColor Cyan
    & cmake --build $buildDir --config Release --target blackrock-ps3 --parallel 4
    if ($LASTEXITCODE -ne 0) { throw "CMake build failed (exit $LASTEXITCODE)." }

    $exe = Join-Path $outDir 'blackrock-ps3.exe'
    if (-not (Test-Path -LiteralPath $exe -PathType Leaf)) {
        throw "The build finished but the EXE was not found at $exe"
    }
    if (-not (Test-Path -LiteralPath (Join-Path $outDir 'data') -PathType Container)) {
        throw 'The compiled EXE exists but its data folder is missing.'
    }

    New-Item -Path $distDir -ItemType Directory -Force | Out-Null
    if (Test-Path -LiteralPath $releaseDir) { Remove-Item -LiteralPath $releaseDir -Recurse -Force }
    New-Item -Path $releaseDir -ItemType Directory -Force | Out-Null
    Copy-Item -LiteralPath $exe -Destination $releaseDir -Force
    Copy-Item -LiteralPath (Join-Path $outDir 'data') -Destination $releaseDir -Recurse -Force
    @'
Blackrock PS3 - connection-fixed build

This build contains the PS3MAPI connection stability patch.
It is NOT a confirmed fix for entity-spawn freezes or pickup-filter activation.
The app must run with its data/ folder in the same directory as the EXE.
Back up original files; do not run both the old and new app simultaneously.
No live-console testing was possible in the build environment.
'@ | Set-Content -LiteralPath (Join-Path $releaseDir 'README.txt') -Encoding UTF8

    $sum = (Get-FileHash -LiteralPath (Join-Path $releaseDir 'blackrock-ps3.exe') -Algorithm SHA256).Hash
    "SHA256 blackrock-ps3.exe: $sum" | Set-Content -LiteralPath (Join-Path $releaseDir 'SHA256.txt') -Encoding ASCII
    if (Test-Path -LiteralPath $archive) { Remove-Item -LiteralPath $archive -Force }
    Compress-Archive -LiteralPath $releaseDir -DestinationPath $archive -CompressionLevel Optimal
    if (-not (Test-Path -LiteralPath $archive)) { throw 'Packaging failed.' }
    Write-Host ''
    Write-Host 'SUCCESS — NEW EXE:' -ForegroundColor Green
    Write-Host "  $exe"
    Write-Host 'SUCCESS — SHAREABLE RELEASE ZIP:' -ForegroundColor Green
    Write-Host "  $archive"
} catch {
    Write-Host ''
    Write-Error "BUILD FAILED: $_"
    exit 1
}
